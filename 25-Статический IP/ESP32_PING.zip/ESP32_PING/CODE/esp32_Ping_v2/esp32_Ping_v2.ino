#include <WiFi.h>
#include <ESP32Ping.h>
const char* ssid     = "";             // ssid домашней сети
const char* password = "";             // пароль от домашней сети
const char* remote_host = "ya.ru";     // Сайт Яндекс

void setup() {
  Serial.begin(115200);
  delay(10);
  // Подключаемся к сети Wi-Fi
  Serial.println();
  Serial.println("Connecting to WiFi");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("WiFi connected with ip ");
  Serial.println(WiFi.localIP());
  Serial.print("ping ");
  Serial.println(remote_host);

  for (int i = 0; i < 4; i++ ) {          // выполняем команду 4 раза
    if (Ping.ping(remote_host, 1)) {      // пинг по имени хоста
      Serial.print(Ping.averageTime());   // выводим время отклика
      Serial.println(" мс");              // миллисекунды
      delay(100);
    } else {
      Serial.println("Error");            // не смогли достучаться до сайта
    }
  }
}

void loop() {}
